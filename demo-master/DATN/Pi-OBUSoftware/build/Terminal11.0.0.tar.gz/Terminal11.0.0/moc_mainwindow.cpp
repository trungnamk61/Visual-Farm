/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Terminal1/mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      65,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x05,

 // slots: signature, parameters, type, tag, flags
      24,   11,   11,   11, 0x08,
      41,   11,   11,   11, 0x08,
      58,   11,   11,   11, 0x08,
      67,   11,   11,   11, 0x08,
      76,   11,   11,   11, 0x08,
      91,   11,   11,   11, 0x08,
     106,   11,   11,   11, 0x08,
     120,   11,   11,   11, 0x08,
     142,   11,   11,   11, 0x08,
     164,   11,   11,   11, 0x08,
     181,   11,   11,   11, 0x08,
     204,   11,   11,   11, 0x08,
     230,  228,   11,   11, 0x08,
     251,   11,   11,   11, 0x08,
     278,   11,   11,   11, 0x08,
     297,   11,   11,   11, 0x08,
     311,   11,   11,   11, 0x08,
     328,  228,   11,   11, 0x08,
     352,   11,   11,   11, 0x08,
     370,   11,   11,   11, 0x08,
     395,   11,   11,   11, 0x08,
     421,   11,   11,   11, 0x08,
     449,   11,   11,   11, 0x08,
     475,   11,   11,   11, 0x08,
     497,   11,   11,   11, 0x08,
     520,   11,   11,   11, 0x08,
     543,   11,   11,   11, 0x08,
     567,   11,   11,   11, 0x08,
     591,   11,   11,   11, 0x08,
     615,   11,   11,   11, 0x08,
     633,   11,   11,   11, 0x08,
     649,   11,   11,   11, 0x08,
     661,   11,   11,   11, 0x08,
     673,   11,   11,   11, 0x08,
     685,   11,   11,   11, 0x08,
     700,   11,   11,   11, 0x08,
     718,   11,   11,   11, 0x08,
     742,   11,   11,   11, 0x08,
     760,   11,   11,   11, 0x08,
     778,   11,   11,   11, 0x08,
     793,   11,   11,   11, 0x08,
     814,   11,   11,   11, 0x08,
     835,   11,   11,   11, 0x08,
     847,   11,   11,   11, 0x08,
     858,   11,   11,   11, 0x08,
     872,   11,   11,   11, 0x08,
     892,  889,   11,   11, 0x08,
     929,  925,   11,   11, 0x08,
     975,  228,   11,   11, 0x08,
    1007,   11,   11,   11, 0x08,
    1023,  889,   11,   11, 0x08,
    1053,  228,   11,   11, 0x08,
    1067,  889,   11,   11, 0x08,
    1095,  228,   11,   11, 0x08,
    1117,  228,   11,   11, 0x08,
    1137,  228,   11,   11, 0x08,
    1158,   11,   11,   11, 0x08,
    1179,  228,   11,   11, 0x08,
    1199,  228,   11,   11, 0x08,
    1220,   11,   11,   11, 0x08,
    1234,   11,   11,   11, 0x08,
    1245,   11,   11,   11, 0x08,
    1273,   11,   11,   11, 0x08,

 // methods: signature, parameters, type, tag, flags
    1304,  228,   11,   11, 0x02,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0readySend()\0onrunTimerP(int)\0"
    "onrunTimerL(int)\0onoffP()\0onoffL()\0"
    "oncountdownP()\0oncountdownL()\0"
    "onCommandLR()\0on_btnPrint_clicked()\0"
    "on_btnClear_clicked()\0Send_Broadcast()\0"
    "autoTakePhoto(QString)\0on_pushButton_clicked()\0"
    ",\0sendCommand(int,int)\0"
    "onOpenCloseButtonClicked()\0"
    "onGpsData(QString)\0initMap(bool)\0"
    "initListSensor()\0onNodeJoin(int,QString)\0"
    "onNodeJoinLR(int)\0onImageReceived(QString)\0"
    "onTranceiverData(QString)\0"
    "onTranceiverDataLI(QString)\0"
    "onreceivedDataLR(QString)\0"
    "onTempAndHum(QString)\0onTempAndHum1(QString)\0"
    "oncompleteLux(QString)\0onTempAndHumLR(QString)\0"
    "oncompleteMois(QString)\0oncompleteDust(QString)\0"
    "onGpsStatus(bool)\0startLinphone()\0"
    "ShowAbout()\0RetaskOne()\0RetaskAll()\0"
    "AddNewSensor()\0EditSensorPlace()\0"
    "ShowSensorInformation()\0StartupLocation()\0"
    "SetupSerialPort()\0SendToServer()\0"
    "on_btnExit_clicked()\0on_btnView_clicked()\0"
    "sendtoWeb()\0sendMqtt()\0mqttConnect()\0"
    "connectEnabled()\0,,\0"
    "sendMqttData(int,double,QString)\0,,,\0"
    "sendMqttDataSaved(QString,int,double,QString)\0"
    "sendImageToWeb(QString,QString)\0"
    "sendBroadcast()\0onTempHumi(int,double,double)\0"
    "onLR(int,int)\0SendAITH(int,double,double)\0"
    "SendAILUX(int,double)\0SendAIMois(int,int)\0"
    "SendAIDD(int,double)\0SendWarningDust(int)\0"
    "onLux_t(int,double)\0onMois_t(int,double)\0"
    "onST(QString)\0makePlot()\0"
    "WriteDatatoLogfile(QString)\0"
    "on_btnConfigThreshol_clicked()\0"
    "mySendCommand(int,int)\0"
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->readySend(); break;
        case 1: _t->onrunTimerP((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->onrunTimerL((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->onoffP(); break;
        case 4: _t->onoffL(); break;
        case 5: _t->oncountdownP(); break;
        case 6: _t->oncountdownL(); break;
        case 7: _t->onCommandLR(); break;
        case 8: _t->on_btnPrint_clicked(); break;
        case 9: _t->on_btnClear_clicked(); break;
        case 10: _t->Send_Broadcast(); break;
        case 11: _t->autoTakePhoto((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 12: _t->on_pushButton_clicked(); break;
        case 13: _t->sendCommand((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 14: _t->onOpenCloseButtonClicked(); break;
        case 15: _t->onGpsData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 16: _t->initMap((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 17: _t->initListSensor(); break;
        case 18: _t->onNodeJoin((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 19: _t->onNodeJoinLR((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->onImageReceived((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 21: _t->onTranceiverData((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 22: _t->onTranceiverDataLI((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 23: _t->onreceivedDataLR((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 24: _t->onTempAndHum((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 25: _t->onTempAndHum1((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 26: _t->oncompleteLux((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 27: _t->onTempAndHumLR((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 28: _t->oncompleteMois((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 29: _t->oncompleteDust((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 30: _t->onGpsStatus((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 31: _t->startLinphone(); break;
        case 32: _t->ShowAbout(); break;
        case 33: _t->RetaskOne(); break;
        case 34: _t->RetaskAll(); break;
        case 35: _t->AddNewSensor(); break;
        case 36: _t->EditSensorPlace(); break;
        case 37: _t->ShowSensorInformation(); break;
        case 38: _t->StartupLocation(); break;
        case 39: _t->SetupSerialPort(); break;
        case 40: _t->SendToServer(); break;
        case 41: _t->on_btnExit_clicked(); break;
        case 42: _t->on_btnView_clicked(); break;
        case 43: _t->sendtoWeb(); break;
        case 44: _t->sendMqtt(); break;
        case 45: _t->mqttConnect(); break;
        case 46: _t->connectEnabled(); break;
        case 47: _t->sendMqttData((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 48: _t->sendMqttDataSaved((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 49: _t->sendImageToWeb((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 50: _t->sendBroadcast(); break;
        case 51: _t->onTempHumi((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        case 52: _t->onLR((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 53: _t->SendAITH((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< double(*)>(_a[3]))); break;
        case 54: _t->SendAILUX((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 55: _t->SendAIMois((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 56: _t->SendAIDD((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 57: _t->SendWarningDust((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 58: _t->onLux_t((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 59: _t->onMois_t((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 60: _t->onST((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 61: _t->makePlot(); break;
        case 62: _t->WriteDatatoLogfile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 63: _t->on_btnConfigThreshol_clicked(); break;
        case 64: _t->mySendCommand((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData MainWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 65)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 65;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::readySend()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
QT_END_MOC_NAMESPACE
